WITH C060_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C060_result (c1, c2) AS (
SELECT COUNT(*) AS row_count, SUM(amount) AS total FROM C060_orders WHERE amount > 100
),
C060_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C060_result q),
C061_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C061_result (c1) AS (
SELECT COUNT(*) AS row_count FROM C061_orders WHERE amount > 100 HAVING COUNT(*) > 0
),
C061_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C061_result q),
C062_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
UNION ALL
SELECT 104, 3, 150 FROM dual
),
C062_result (c1, c2) AS (
SELECT order_id, amount FROM C062_orders WHERE amount > 100 ORDER BY order_id
),
C062_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C062_result q),
C063_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
UNION ALL
SELECT 104, 3, 150 FROM dual
),
C063_result (c1, c2) AS (
SELECT COUNT(*) AS row_count, SUM(amount) AS total FROM C063_orders WHERE amount > 100
),
C063_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C063_result q),
C064_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C064_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C064_result (c1) AS (
SELECT customer_id FROM C064_customers WHERE customer_id IN (SELECT customer_id FROM C064_orders) ORDER BY customer_id
),
C064_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C064_result q),
C065_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C065_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C065_result (c1) AS (
SELECT c.customer_id FROM C065_customers c WHERE EXISTS (SELECT NULL FROM C065_orders o WHERE o.customer_id=c.customer_id) ORDER BY c.customer_id
),
C065_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C065_result q),
C066_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C066_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C066_result (c1) AS (
SELECT c.customer_id FROM C066_customers c WHERE NOT EXISTS (SELECT NULL FROM C066_orders o WHERE o.customer_id=c.customer_id) ORDER BY c.customer_id
),
C066_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C066_result q),
C067_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C067_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
UNION ALL
SELECT 104, 1, 30 FROM dual
),
C067_result (c1) AS (
SELECT customer_id FROM C067_customers WHERE customer_id IN (SELECT customer_id FROM C067_orders) ORDER BY customer_id
),
C067_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C067_result q),
C068_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C068_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
UNION ALL
SELECT 104, 1, 30 FROM dual
),
C068_result (c1) AS (
SELECT c.customer_id FROM C068_customers c WHERE EXISTS (SELECT NULL FROM C068_orders o WHERE o.customer_id=c.customer_id) ORDER BY c.customer_id
),
C068_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C068_result q),
C069_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C069_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
UNION ALL
SELECT 104, 1, 30 FROM dual
),
C069_result (c1) AS (
SELECT c.customer_id FROM C069_customers c WHERE NOT EXISTS (SELECT NULL FROM C069_orders o WHERE o.customer_id=c.customer_id) ORDER BY c.customer_id
),
C069_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C069_result q)
SELECT 'C060' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C060_numbered
UNION ALL
SELECT 'C061' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C061_numbered
UNION ALL
SELECT 'C062' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C062_numbered
UNION ALL
SELECT 'C063' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C063_numbered
UNION ALL
SELECT 'C064' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C064_numbered
UNION ALL
SELECT 'C065' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C065_numbered
UNION ALL
SELECT 'C066' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C066_numbered
UNION ALL
SELECT 'C067' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C067_numbered
UNION ALL
SELECT 'C068' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C068_numbered
UNION ALL
SELECT 'C069' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C069_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
