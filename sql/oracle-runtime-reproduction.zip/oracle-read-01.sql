WITH C010_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C010_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C010_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C010_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C010_result (c1, c2) AS (
SELECT SUM(amount),COUNT(*) FROM C010_orders WHERE 1=0
),
C010_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C010_result q),
C011_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C011_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C011_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C011_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C011_result (c1, c2) AS (
SELECT c.customer_id,o.order_id
FROM C011_customers c LEFT JOIN C011_orders o ON c.customer_id=o.customer_id ORDER BY c.customer_id,o.order_id
),
C011_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C011_result q),
C012_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C012_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C012_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C012_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C012_result (c1, c2) AS (
SELECT c.customer_id,o.order_id
FROM C012_customers c INNER JOIN C012_orders o ON c.customer_id=o.customer_id ORDER BY c.customer_id,o.order_id
),
C012_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C012_result q),
C013_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C013_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C013_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
UNION ALL
SELECT 204, 22, 9, CAST(NULL AS NUMBER), 1 FROM dual
),
C013_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C013_result (c1, c2) AS (
SELECT c.customer_id,o.order_id
FROM C013_customers c LEFT JOIN C013_orders o ON c.customer_id=o.customer_id ORDER BY c.customer_id,o.order_id
),
C013_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C013_result q),
C014_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C014_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C014_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C014_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C014_result (c1, c2, c3) AS (
SELECT c.customer_id,
COUNT(*),COUNT(o.order_id) FROM C014_customers c LEFT JOIN C014_orders o
ON c.customer_id=o.customer_id GROUP BY c.customer_id ORDER BY c.customer_id
),
C014_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C014_result q),
C015_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C015_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C015_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT CAST(NULL AS NUMBER), CAST(NULL AS NUMBER), CAST(NULL AS NUMBER), CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual WHERE 1=0
),
C015_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C015_result (c1, c2) AS (
SELECT c.customer_id,o.order_id
FROM C015_customers c LEFT JOIN C015_orders o ON c.customer_id=o.customer_id ORDER BY c.customer_id,o.order_id
),
C015_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C015_result q),
C016_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C016_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C016_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C016_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C016_result (c1, c2) AS (
SELECT c.customer_id,o.order_id
FROM C016_customers c LEFT JOIN C016_orders o ON c.customer_id=o.customer_id AND o.amount>=10 ORDER BY c.customer_id,o.order_id
),
C016_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C016_result q),
C017_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C017_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C017_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C017_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C017_result (c1, c2) AS (
SELECT c.customer_id,o.order_id
FROM C017_customers c LEFT JOIN C017_orders o ON c.customer_id=o.customer_id WHERE o.amount>=10 ORDER BY c.customer_id,o.order_id
),
C017_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C017_result q),
C018_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C018_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C018_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C018_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C018_result (c1, c2) AS (
SELECT c.customer_id,o.order_id
FROM C018_customers c LEFT JOIN C018_orders o ON c.customer_id=o.customer_id WHERE o.amount>=10 OR o.order_id IS NULL ORDER BY c.customer_id,o.order_id
),
C018_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C018_result q),
C019_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C019_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C019_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 0, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 0, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 0, 500, 3 FROM dual
),
C019_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C019_result (c1, c2) AS (
SELECT c.customer_id,o.order_id
FROM C019_customers c LEFT JOIN C019_orders o ON c.customer_id=o.customer_id AND o.amount>=10 ORDER BY c.customer_id,o.order_id
),
C019_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C019_result q)
SELECT 'C010' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C010_numbered
UNION ALL
SELECT 'C011' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C011_numbered
UNION ALL
SELECT 'C012' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C012_numbered
UNION ALL
SELECT 'C013' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C013_numbered
UNION ALL
SELECT 'C014' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C014_numbered
UNION ALL
SELECT 'C015' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C015_numbered
UNION ALL
SELECT 'C016' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C016_numbered
UNION ALL
SELECT 'C017' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C017_numbered
UNION ALL
SELECT 'C018' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C018_numbered
UNION ALL
SELECT 'C019' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C019_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
