WITH C090_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
UNION ALL
SELECT 4, 'MIN' FROM dual
),
C090_result (c1, c2) AS (
SELECT customer_id, customer_name FROM C090_customers ORDER BY customer_id
),
C090_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C090_result q),
C091_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
UNION ALL
SELECT 4, 'MIN' FROM dual
),
C091_result (c1) AS (
SELECT COUNT(*) AS instance_count FROM C091_customers
),
C091_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C091_result q),
C092_items (item_id, quantity, unit_price) AS (
SELECT 1, 2, 30 FROM dual
UNION ALL
SELECT 2, 3, 20 FROM dual
),
C092_result (c1, c2, c3, c4) AS (
SELECT item_id, quantity, unit_price, quantity*unit_price AS amount FROM C092_items ORDER BY item_id
),
C092_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C092_result q),
C093_items (item_id, quantity, unit_price) AS (
SELECT 1, 4, 30 FROM dual
UNION ALL
SELECT 2, 3, 20 FROM dual
),
C093_result (c1, c2, c3, c4) AS (
SELECT item_id, quantity, unit_price, quantity*unit_price AS amount FROM C093_items ORDER BY item_id
),
C093_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C093_result q),
C094_enrollments (student_id, course_id) AS (
SELECT 1, 10 FROM dual
UNION ALL
SELECT 1, 20 FROM dual
UNION ALL
SELECT 2, 10 FROM dual
),
C094_result (c1, c2, c3) AS (
SELECT student_id, course_id, COUNT(*) AS row_count FROM C094_enrollments GROUP BY student_id, course_id HAVING COUNT(*)>1 ORDER BY student_id, course_id
),
C094_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C094_result q),
C095_enrollments (student_id, course_id) AS (
SELECT 1, 10 FROM dual
UNION ALL
SELECT 1, 20 FROM dual
UNION ALL
SELECT 2, 10 FROM dual
),
C095_result (c1, c2) AS (
SELECT student_id, COUNT(*) AS row_count FROM C095_enrollments GROUP BY student_id HAVING COUNT(*)>1 ORDER BY student_id
),
C095_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C095_result q),
C096_enrollments (student_id, course_id) AS (
SELECT 1, 10 FROM dual
UNION ALL
SELECT 1, 20 FROM dual
UNION ALL
SELECT 2, 10 FROM dual
UNION ALL
SELECT 1, 10 FROM dual
),
C096_result (c1, c2, c3) AS (
SELECT student_id, course_id, COUNT(*) AS row_count FROM C096_enrollments GROUP BY student_id, course_id HAVING COUNT(*)>1 ORDER BY student_id, course_id
),
C096_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C096_result q),
C097_order_lines (order_id, line_no, line_id, product_id) AS (
SELECT 101, 1, 1, 10 FROM dual
UNION ALL
SELECT 101, 2, 2, 20 FROM dual
UNION ALL
SELECT 102, 1, 3, 10 FROM dual
),
C097_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C097_result (c1, c2, c3) AS (
SELECT order_id, line_no, line_id FROM C097_order_lines ORDER BY order_id, line_no
),
C097_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C097_result q),
C098_order_lines (order_id, line_no, line_id, product_id) AS (
SELECT 101, 1, 1, 10 FROM dual
UNION ALL
SELECT 101, 2, 2, 20 FROM dual
UNION ALL
SELECT 102, 1, 3, 10 FROM dual
),
C098_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C098_result (c1) AS (
SELECT l.line_id FROM C098_order_lines l WHERE NOT EXISTS (SELECT 1 FROM C098_orders o WHERE o.order_id=l.order_id) ORDER BY l.line_id
),
C098_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C098_result q),
C099_order_lines (order_id, line_no, line_id, product_id) AS (
SELECT 101, 1, 1, 10 FROM dual
UNION ALL
SELECT 101, 2, 2, 20 FROM dual
UNION ALL
SELECT 102, 1, 3, 10 FROM dual
UNION ALL
SELECT 999, 1, 4, 30 FROM dual
),
C099_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C099_result (c1) AS (
SELECT l.line_id FROM C099_order_lines l WHERE NOT EXISTS (SELECT 1 FROM C099_orders o WHERE o.order_id=l.order_id) ORDER BY l.line_id
),
C099_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C099_result q)
SELECT 'C090' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C090_numbered
UNION ALL
SELECT 'C091' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C091_numbered
UNION ALL
SELECT 'C092' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C092_numbered
UNION ALL
SELECT 'C093' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C093_numbered
UNION ALL
SELECT 'C094' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C094_numbered
UNION ALL
SELECT 'C095' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C095_numbered
UNION ALL
SELECT 'C096' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C096_numbered
UNION ALL
SELECT 'C097' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C097_numbered
UNION ALL
SELECT 'C098' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C098_numbered
UNION ALL
SELECT 'C099' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C099_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
