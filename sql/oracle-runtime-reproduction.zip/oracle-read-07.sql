WITH C070_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C070_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C070_result (c1, c2) AS (
SELECT c.customer_id, (SELECT o.amount FROM C070_orders o WHERE o.customer_id=c.customer_id AND o.order_id=103) AS one_amount FROM C070_customers c ORDER BY c.customer_id
),
C070_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C070_result q),
C071_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C071_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
UNION ALL
SELECT 104, 3, 7 FROM dual
),
C071_result (c1, c2) AS (
SELECT c.customer_id, (SELECT o.amount FROM C071_orders o WHERE o.customer_id=c.customer_id AND o.order_id=104) AS one_amount FROM C071_customers c ORDER BY c.customer_id
),
C071_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C071_result q),
C072_sales (sale_id, region_id, product_id, amount) AS (
SELECT 1, 1, 10, 10 FROM dual
UNION ALL
SELECT 2, 1, 20, 20 FROM dual
UNION ALL
SELECT 3, 2, 10, 5 FROM dual
),
C072_result (c1, c2, c3) AS (
SELECT region_id, product_id, SUM(amount) AS total FROM C072_sales GROUP BY region_id, product_id ORDER BY region_id, product_id
),
C072_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C072_result q),
C073_sales (sale_id, region_id, product_id, amount) AS (
SELECT 1, 1, 10, 10 FROM dual
UNION ALL
SELECT 2, 1, 20, 20 FROM dual
UNION ALL
SELECT 3, 2, 10, 5 FROM dual
),
C073_result (c1, c2, c3) AS (
SELECT region_id, product_id, SUM(amount) AS total FROM C073_sales GROUP BY product_id, region_id ORDER BY region_id, product_id
),
C073_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C073_result q),
C074_sales (sale_id, region_id, product_id, amount) AS (
SELECT 1, 1, 10, 10 FROM dual
UNION ALL
SELECT 2, 1, 20, 20 FROM dual
UNION ALL
SELECT 3, 2, 10, 5 FROM dual
),
C074_result (c1, c2, c3) AS (
SELECT region_id, product_id, SUM(amount) AS total FROM C074_sales GROUP BY region_id, product_id ORDER BY region_id DESC, product_id DESC
),
C074_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C074_result q),
C075_sales (sale_id, region_id, product_id, amount) AS (
SELECT 1, 1, 10, 10 FROM dual
UNION ALL
SELECT 2, 1, 20, 20 FROM dual
UNION ALL
SELECT 3, 2, 10, 5 FROM dual
),
C075_result (c1, c2, c3, c4) AS (
SELECT 0 AS level_no, region_id, product_id, SUM(amount) AS total FROM C075_sales GROUP BY region_id, product_id UNION ALL SELECT 1 AS level_no, region_id, CAST(NULL AS INTEGER) AS product_id, SUM(amount) AS total FROM C075_sales GROUP BY region_id UNION ALL SELECT 3 AS level_no, CAST(NULL AS INTEGER) AS region_id, CAST(NULL AS INTEGER) AS product_id, SUM(amount) AS total FROM C075_sales ORDER BY level_no, region_id, product_id
),
C075_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C075_result q),
C076_sales (sale_id, region_id, product_id, amount) AS (
SELECT 1, 1, 10, 10 FROM dual
UNION ALL
SELECT 2, 1, 20, 20 FROM dual
UNION ALL
SELECT 3, 2, 10, 5 FROM dual
),
C076_result (c1, c2, c3, c4) AS (
SELECT 0 AS level_no, region_id, product_id, SUM(amount) AS total FROM C076_sales GROUP BY region_id, product_id UNION ALL SELECT 1 AS level_no, region_id, CAST(NULL AS INTEGER) AS product_id, SUM(amount) AS total FROM C076_sales GROUP BY region_id UNION ALL SELECT 2 AS level_no, CAST(NULL AS INTEGER) AS region_id, product_id, SUM(amount) AS total FROM C076_sales GROUP BY product_id UNION ALL SELECT 3 AS level_no, CAST(NULL AS INTEGER) AS region_id, CAST(NULL AS INTEGER) AS product_id, SUM(amount) AS total FROM C076_sales ORDER BY level_no, region_id, product_id
),
C076_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C076_result q),
C077_sales (sale_id, region_id, product_id, amount) AS (
SELECT 1, 1, 10, 10 FROM dual
UNION ALL
SELECT 2, 1, 10, 20 FROM dual
UNION ALL
SELECT 3, 2, 10, 5 FROM dual
),
C077_result (c1, c2, c3, c4) AS (
SELECT 0 AS level_no, region_id, product_id, SUM(amount) AS total FROM C077_sales GROUP BY region_id, product_id UNION ALL SELECT 1 AS level_no, region_id, CAST(NULL AS INTEGER) AS product_id, SUM(amount) AS total FROM C077_sales GROUP BY region_id UNION ALL SELECT 2 AS level_no, CAST(NULL AS INTEGER) AS region_id, product_id, SUM(amount) AS total FROM C077_sales GROUP BY product_id UNION ALL SELECT 3 AS level_no, CAST(NULL AS INTEGER) AS region_id, CAST(NULL AS INTEGER) AS product_id, SUM(amount) AS total FROM C077_sales ORDER BY level_no, region_id, product_id
),
C077_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C077_result q),
C078_sales (sale_id, region_id, amount) AS (
SELECT 1, 1, 10 FROM dual
UNION ALL
SELECT 2, CAST(NULL AS NUMBER), 5 FROM dual
UNION ALL
SELECT 3, 1, 20 FROM dual
),
C078_result (c1, c2, c3) AS (
SELECT subtotal_flag, region_id, total FROM (SELECT 0 AS subtotal_flag, region_id, SUM(amount) AS total FROM C078_sales GROUP BY region_id UNION ALL SELECT 1 AS subtotal_flag, CAST(NULL AS INTEGER) AS region_id, SUM(amount) AS total FROM C078_sales) x ORDER BY subtotal_flag, CASE WHEN region_id IS NULL THEN 1 ELSE 0 END, region_id
),
C078_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C078_result q),
C079_sales (sale_id, region_id, amount) AS (
SELECT 1, 1, 10 FROM dual
UNION ALL
SELECT 2, 2, 5 FROM dual
UNION ALL
SELECT 3, 1, 20 FROM dual
),
C079_result (c1, c2, c3) AS (
SELECT subtotal_flag, region_id, total FROM (SELECT 0 AS subtotal_flag, region_id, SUM(amount) AS total FROM C079_sales GROUP BY region_id UNION ALL SELECT 1 AS subtotal_flag, CAST(NULL AS INTEGER) AS region_id, SUM(amount) AS total FROM C079_sales) x ORDER BY subtotal_flag, CASE WHEN region_id IS NULL THEN 1 ELSE 0 END, region_id
),
C079_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C079_result q)
SELECT 'C070' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C070_numbered
UNION ALL
SELECT 'C071' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C071_numbered
UNION ALL
SELECT 'C072' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C072_numbered
UNION ALL
SELECT 'C073' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C073_numbered
UNION ALL
SELECT 'C074' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C074_numbered
UNION ALL
SELECT 'C075' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C075_numbered
UNION ALL
SELECT 'C076' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C076_numbered
UNION ALL
SELECT 'C077' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C077_numbered
UNION ALL
SELECT 'C078' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C078_numbered
UNION ALL
SELECT 'C079' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C079_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
