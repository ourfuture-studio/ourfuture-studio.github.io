WITH C100_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C100_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C100_result (c1, c2) AS (
SELECT c.customer_id, COUNT(o.order_id) AS order_count FROM C100_customers c LEFT JOIN C100_orders o ON o.customer_id=c.customer_id GROUP BY c.customer_id ORDER BY c.customer_id
),
C100_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C100_result q),
C101_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C101_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
UNION ALL
SELECT 104, 3, 8 FROM dual
),
C101_result (c1, c2) AS (
SELECT c.customer_id, COUNT(o.order_id) AS order_count FROM C101_customers c LEFT JOIN C101_orders o ON o.customer_id=c.customer_id GROUP BY c.customer_id ORDER BY c.customer_id
),
C101_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C101_result q),
C102_flat_orders (order_id, product_id, product_name, category_id, category_name, quantity) AS (
SELECT 101, 10, 'TEA', 1, 'DRINK', 2 FROM dual
UNION ALL
SELECT 101, 20, 'CAKE', 2, 'FOOD', 1 FROM dual
UNION ALL
SELECT 102, 10, 'TEA', 1, 'DRINK', 3 FROM dual
),
C102_result (c1, c2) AS (
SELECT product_id, COUNT(DISTINCT product_name) AS name_count FROM C102_flat_orders GROUP BY product_id ORDER BY product_id
),
C102_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C102_result q),
C103_flat_orders (order_id, product_id, product_name, category_id, category_name, quantity) AS (
SELECT 101, 10, 'TEA', 1, 'DRINK', 2 FROM dual
UNION ALL
SELECT 101, 20, 'CAKE', 2, 'FOOD', 1 FROM dual
UNION ALL
SELECT 102, 10, 'TEA', 1, 'DRINK', 3 FROM dual
),
C103_result (c1, c2) AS (
SELECT category_id, COUNT(DISTINCT category_name) AS name_count FROM C103_flat_orders GROUP BY category_id ORDER BY category_id
),
C103_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C103_result q),
C104_flat_orders (order_id, product_id, product_name, category_id, category_name, quantity) AS (
SELECT 101, 10, 'TEA', 1, 'DRINK', 2 FROM dual
UNION ALL
SELECT 101, 20, 'CAKE', 2, 'FOOD', 1 FROM dual
UNION ALL
SELECT 102, 10, 'TEA', 1, 'BEVERAGE', 3 FROM dual
),
C104_result (c1, c2) AS (
SELECT category_id, COUNT(DISTINCT category_name) AS name_count FROM C104_flat_orders GROUP BY category_id ORDER BY category_id
),
C104_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C104_result q),
C105_bookings (booking_id, customer_id, slot_no) AS (
SELECT 1, 1, 10 FROM dual
UNION ALL
SELECT 2, 1, 10 FROM dual
UNION ALL
SELECT 3, 2, 20 FROM dual
),
C105_result (c1, c2) AS (
SELECT COUNT(*) AS rows_n, COUNT(DISTINCT booking_id) AS id_count FROM C105_bookings
),
C105_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C105_result q),
C106_bookings (booking_id, customer_id, slot_no) AS (
SELECT 1, 1, 10 FROM dual
UNION ALL
SELECT 2, 1, 10 FROM dual
UNION ALL
SELECT 3, 2, 20 FROM dual
),
C106_result (c1, c2, c3) AS (
SELECT customer_id, slot_no, COUNT(*) AS row_count FROM C106_bookings GROUP BY customer_id, slot_no HAVING COUNT(*)>1 ORDER BY customer_id, slot_no
),
C106_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C106_result q),
C107_bookings (booking_id, customer_id, slot_no) AS (
SELECT 1, 1, 10 FROM dual
UNION ALL
SELECT 2, 1, 11 FROM dual
UNION ALL
SELECT 3, 2, 20 FROM dual
),
C107_result (c1, c2) AS (
SELECT COUNT(*) AS rows_n, COUNT(DISTINCT booking_id) AS id_count FROM C107_bookings
),
C107_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C107_result q),
C108_bookings (booking_id, customer_id, slot_no) AS (
SELECT 1, 1, 10 FROM dual
UNION ALL
SELECT 2, 1, 11 FROM dual
UNION ALL
SELECT 3, 2, 20 FROM dual
),
C108_result (c1, c2, c3) AS (
SELECT customer_id, slot_no, COUNT(*) AS row_count FROM C108_bookings GROUP BY customer_id, slot_no HAVING COUNT(*)>1 ORDER BY customer_id, slot_no
),
C108_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C108_result q),
C109_candidate_orders (order_id, customer_id, amount) AS (
SELECT 201, 1, 10 FROM dual
UNION ALL
SELECT 202, 3, 5 FROM dual
),
C109_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C109_result (c1, c2, c3, c4) AS (
SELECT x.order_id, x.customer_id, x.amount, CASE WHEN c.customer_id IS NULL THEN 'INVALID_PARENT' ELSE 'VALID_PARENT' END AS reference_status FROM C109_candidate_orders x LEFT JOIN C109_customers c ON c.customer_id=x.customer_id ORDER BY x.order_id
),
C109_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C109_result q)
SELECT 'C100' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C100_numbered
UNION ALL
SELECT 'C101' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C101_numbered
UNION ALL
SELECT 'C102' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C102_numbered
UNION ALL
SELECT 'C103' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C103_numbered
UNION ALL
SELECT 'C104' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C104_numbered
UNION ALL
SELECT 'C105' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C105_numbered
UNION ALL
SELECT 'C106' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C106_numbered
UNION ALL
SELECT 'C107' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C107_numbered
UNION ALL
SELECT 'C108' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C108_numbered
UNION ALL
SELECT 'C109' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C109_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
