WITH C110_candidate_orders (order_id, customer_id, amount) AS (
SELECT 201, 1, 10 FROM dual
UNION ALL
SELECT 202, 99, 5 FROM dual
),
C110_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C110_result (c1, c2, c3, c4) AS (
SELECT x.order_id, x.customer_id, x.amount, CASE WHEN c.customer_id IS NULL THEN 'INVALID_PARENT' ELSE 'VALID_PARENT' END AS reference_status FROM C110_candidate_orders x LEFT JOIN C110_customers c ON c.customer_id=x.customer_id ORDER BY x.order_id
),
C110_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C110_result q),
C111_candidates (candidate_id, quantity) AS (
SELECT 1, 2 FROM dual
UNION ALL
SELECT 2, 0 FROM dual
UNION ALL
SELECT 3, CAST(NULL AS NUMBER) FROM dual
),
C111_result (c1, c2, c3, c4) AS (
SELECT candidate_id, quantity, CASE WHEN quantity>0 THEN 'TRUE' WHEN NOT(quantity>0) THEN 'FALSE' ELSE 'UNKNOWN' END AS predicate, CASE WHEN NOT(quantity>0) THEN 'REJECT' ELSE 'PASS_CHECK' END AS check_status FROM C111_candidates ORDER BY candidate_id
),
C111_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C111_result q),
C112_candidates (candidate_id, quantity) AS (
SELECT 1, 2 FROM dual
UNION ALL
SELECT 2, 0 FROM dual
UNION ALL
SELECT 3, CAST(NULL AS NUMBER) FROM dual
),
C112_result (c1, c2) AS (
SELECT candidate_id, CASE WHEN quantity IS NOT NULL AND quantity>0 THEN 'PASS' ELSE 'REJECT' END AS combined_status FROM C112_candidates ORDER BY candidate_id
),
C112_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C112_result q),
C113_candidates (candidate_id, quantity) AS (
SELECT 1, 2 FROM dual
UNION ALL
SELECT 2, 0 FROM dual
UNION ALL
SELECT 3, -1 FROM dual
),
C113_result (c1, c2, c3, c4) AS (
SELECT candidate_id, quantity, CASE WHEN quantity>0 THEN 'TRUE' WHEN NOT(quantity>0) THEN 'FALSE' ELSE 'UNKNOWN' END AS predicate, CASE WHEN NOT(quantity>0) THEN 'REJECT' ELSE 'PASS_CHECK' END AS check_status FROM C113_candidates ORDER BY candidate_id
),
C113_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C113_result q),
C114_texts (row_id, text_value) AS (
SELECT 1, CAST(NULL AS VARCHAR2(200)) FROM dual
UNION ALL
SELECT 2, ' ' FROM dual
UNION ALL
SELECT 3, 'A' FROM dual
),
C114_result (c1, c2, c3) AS (
SELECT row_id, CASE WHEN text_value IS NULL THEN 'NULL' ELSE 'VALUE' END AS value_kind, LENGTH(text_value) AS char_count FROM C114_texts ORDER BY row_id
),
C114_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C114_result q),
C115_texts (row_id, text_value) AS (
SELECT 1, CAST(NULL AS VARCHAR2(200)) FROM dual
UNION ALL
SELECT 2, '  ' FROM dual
UNION ALL
SELECT 3, 'A' FROM dual
),
C115_result (c1, c2, c3) AS (
SELECT row_id, CASE WHEN text_value IS NULL THEN 'NULL' ELSE 'VALUE' END AS value_kind, LENGTH(text_value) AS char_count FROM C115_texts ORDER BY row_id
),
C115_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C115_result q),
C116_key_candidates (row_id, code) AS (
SELECT 1, 10 FROM dual
UNION ALL
SELECT 2, 10 FROM dual
UNION ALL
SELECT 3, CAST(NULL AS NUMBER) FROM dual
),
C116_result (c1, c2, c3, c4, c5) AS (
SELECT k.row_id, k.code, CASE WHEN k.code IS NULL THEN 'FAIL' ELSE 'PASS' END AS not_null_status, CASE WHEN k.code IS NOT NULL AND EXISTS (SELECT 1 FROM C116_key_candidates x WHERE x.row_id<>k.row_id AND x.code=k.code) THEN 'FAIL' ELSE 'PASS' END AS unique_status, CASE WHEN k.code IS NULL OR EXISTS (SELECT 1 FROM C116_key_candidates x WHERE x.row_id<>k.row_id AND x.code=k.code) THEN 'FAIL' ELSE 'PASS' END AS primary_key_status FROM C116_key_candidates k ORDER BY k.row_id
),
C116_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C116_result q),
C117_key_candidates (row_id, code) AS (
SELECT 1, 10 FROM dual
UNION ALL
SELECT 2, 20 FROM dual
UNION ALL
SELECT 3, CAST(NULL AS NUMBER) FROM dual
),
C117_result (c1, c2, c3, c4, c5) AS (
SELECT k.row_id, k.code, CASE WHEN k.code IS NULL THEN 'FAIL' ELSE 'PASS' END AS not_null_status, CASE WHEN k.code IS NOT NULL AND EXISTS (SELECT 1 FROM C117_key_candidates x WHERE x.row_id<>k.row_id AND x.code=k.code) THEN 'FAIL' ELSE 'PASS' END AS unique_status, CASE WHEN k.code IS NULL OR EXISTS (SELECT 1 FROM C117_key_candidates x WHERE x.row_id<>k.row_id AND x.code=k.code) THEN 'FAIL' ELSE 'PASS' END AS primary_key_status FROM C117_key_candidates k ORDER BY k.row_id
),
C117_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C117_result q)
SELECT 'C110' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C110_numbered
UNION ALL
SELECT 'C111' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C111_numbered
UNION ALL
SELECT 'C112' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C112_numbered
UNION ALL
SELECT 'C113' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C113_numbered
UNION ALL
SELECT 'C114' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C114_numbered
UNION ALL
SELECT 'C115' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C115_numbered
UNION ALL
SELECT 'C116' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4, c5 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C116_numbered
UNION ALL
SELECT 'C117' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4, c5 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C117_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
