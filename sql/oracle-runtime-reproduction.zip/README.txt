Oracle 19c 19.26.0.0.0 / 2026-10-29
Queries: 122; trace queries: 11; mismatches: 0.
Run each read/trace SQL file as ONE statement. In FreeSQL select all editor content, then Run Statement.
Each packet returns CASE_ID, ROWS_JSON and an ENV version row.
The write script requires a private practice schema and Run Script (F5). It creates a new dedicated SQLD_VERIFY_20261029_ORDERS table and does not DROP or overwrite any existing object.
If that name already exists, choose a fresh name before executing. The test table is retained.
Comparison covers registered fixed inputs and result values/rows/NULL/multiplicity; arbitrary edits and datatype metadata are excluded.
