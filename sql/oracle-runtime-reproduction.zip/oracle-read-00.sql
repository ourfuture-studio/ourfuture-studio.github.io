WITH C000_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C000_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C000_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C000_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C000_result (c1) AS (
SELECT COUNT(coupon_amount) AS coupon_count FROM C000_orders
),
C000_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C000_result q),
C001_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C001_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C001_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C001_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C001_result (c1, c2, c3) AS (
SELECT COUNT(*),COUNT(coupon_amount),
COUNT(DISTINCT coupon_amount) FROM C001_orders
),
C001_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C001_result q),
C002_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C002_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C002_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, 0, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C002_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C002_result (c1, c2, c3) AS (
SELECT COUNT(*) AS rows_n, COUNT(coupon_amount) AS values_n, COUNT(DISTINCT coupon_amount) AS distinct_n FROM C002_orders
),
C002_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C002_result q),
C003_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C003_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C003_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, CAST(NULL AS NUMBER), 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, CAST(NULL AS NUMBER), 3 FROM dual
),
C003_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C003_result (c1, c2, c3) AS (
SELECT COUNT(*),COUNT(coupon_amount),
COUNT(DISTINCT coupon_amount) FROM C003_orders
),
C003_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C003_result q),
C004_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C004_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C004_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT CAST(NULL AS NUMBER), CAST(NULL AS NUMBER), CAST(NULL AS NUMBER), CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual WHERE 1=0
),
C004_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C004_result (c1, c2, c3) AS (
SELECT COUNT(*),COUNT(coupon_amount),COUNT(DISTINCT coupon_amount) FROM C004_orders
),
C004_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C004_result q),
C005_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C005_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C005_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C005_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C005_result (c1) AS (
SELECT SUM(amount + fee) AS total FROM C005_orders
),
C005_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C005_result q),
C006_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C006_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C006_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C006_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C006_result (c1) AS (
SELECT SUM(amount) + SUM(fee) AS total FROM C006_orders
),
C006_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C006_result q),
C007_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C007_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C007_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), 0 FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C007_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C007_result (c1) AS (
SELECT SUM(amount+fee) AS total FROM C007_orders
),
C007_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C007_result q),
C008_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C008_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C008_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), 0 FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C008_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C008_result (c1) AS (
SELECT SUM(amount)+SUM(fee) AS total FROM C008_orders
),
C008_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C008_result q),
C009_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C009_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C009_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C009_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C009_result (c1, c2) AS (
SELECT
SUM(COALESCE(amount+fee,0)),
SUM(COALESCE(amount,0)+COALESCE(fee,0)) FROM C009_orders
),
C009_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C009_result q)
SELECT 'C000' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C000_numbered
UNION ALL
SELECT 'C001' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C001_numbered
UNION ALL
SELECT 'C002' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C002_numbered
UNION ALL
SELECT 'C003' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C003_numbered
UNION ALL
SELECT 'C004' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C004_numbered
UNION ALL
SELECT 'C005' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C005_numbered
UNION ALL
SELECT 'C006' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C006_numbered
UNION ALL
SELECT 'C007' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C007_numbered
UNION ALL
SELECT 'C008' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C008_numbered
UNION ALL
SELECT 'C009' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C009_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
