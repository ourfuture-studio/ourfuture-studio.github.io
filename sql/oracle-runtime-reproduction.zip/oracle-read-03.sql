WITH C030_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C030_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C030_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C030_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C030_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C030_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C030_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C030_result (c1) AS (
SELECT order_id FROM C030_null_orders WHERE coupon = NULL ORDER BY order_id
),
C030_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C030_result q),
C031_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C031_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C031_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C031_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C031_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C031_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C031_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C031_result (c1) AS (
SELECT order_id FROM C031_null_orders WHERE coupon IS NULL ORDER BY order_id
),
C031_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C031_result q),
C032_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C032_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C032_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C032_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C032_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C032_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C032_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C032_result (c1) AS (
SELECT order_id FROM C032_null_orders WHERE coupon = 0 ORDER BY order_id
),
C032_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C032_result q),
C033_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C033_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C033_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C033_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C033_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C033_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C033_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C033_result (c1) AS (
SELECT order_id FROM C033_null_orders WHERE coupon <> 500 ORDER BY order_id
),
C033_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C033_result q),
C034_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C034_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C034_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C034_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, 100 FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C034_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C034_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C034_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C034_result (c1) AS (
SELECT order_id FROM C034_null_orders WHERE coupon IS NULL
),
C034_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C034_result q),
C035_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C035_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C035_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C035_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C035_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C035_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C035_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C035_result (c1, c2) AS (
SELECT DISTINCT customer_id, menu FROM C035_purchases
),
C035_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C035_result q),
C036_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C036_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C036_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C036_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C036_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C036_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C036_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C036_result (c1) AS (
SELECT DISTINCT customer_id FROM C036_purchases ORDER BY customer_id
),
C036_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C036_result q),
C037_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C037_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C037_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C037_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C037_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C037_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C037_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C037_result (c1, c2, c3) AS (
SELECT DISTINCT order_id, customer_id, menu FROM C037_purchases ORDER BY order_id
),
C037_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C037_result q),
C038_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C038_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C038_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C038_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C038_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C038_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '커피' FROM dual
UNION ALL
SELECT 404, 11, '커피' FROM dual
),
C038_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C038_result (c1, c2) AS (
SELECT DISTINCT customer_id, menu FROM C038_purchases
),
C038_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C038_result q),
C039_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C039_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C039_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C039_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C039_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C039_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C039_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C039_result (c1) AS (
SELECT customer_id FROM C039_campaign_a UNION SELECT customer_id FROM C039_campaign_b ORDER BY customer_id
),
C039_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C039_result q)
SELECT 'C030' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C030_numbered
UNION ALL
SELECT 'C031' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C031_numbered
UNION ALL
SELECT 'C032' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C032_numbered
UNION ALL
SELECT 'C033' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C033_numbered
UNION ALL
SELECT 'C034' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C034_numbered
UNION ALL
SELECT 'C035' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C035_numbered
UNION ALL
SELECT 'C036' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C036_numbered
UNION ALL
SELECT 'C037' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C037_numbered
UNION ALL
SELECT 'C038' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C038_numbered
UNION ALL
SELECT 'C039' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C039_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
