WITH C020_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C020_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C020_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 0, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 0, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 0, 500, 3 FROM dual
),
C020_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C020_result (c1, c2) AS (
SELECT c.customer_id,o.order_id
FROM C020_customers c LEFT JOIN C020_orders o ON c.customer_id=o.customer_id WHERE o.amount>=10 ORDER BY c.customer_id,o.order_id
),
C020_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C020_result q),
C021_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C021_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C021_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C021_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C021_result (c1) AS (
SELECT customer_id FROM C021_customers
WHERE customer_id NOT IN (SELECT customer_id FROM C021_excluded_customers)
ORDER BY customer_id
),
C021_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C021_result q),
C022_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C022_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C022_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C022_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C022_result (c1, c2) AS (
SELECT customer_id, CASE WHEN customer_id NOT IN (SELECT customer_id FROM C022_excluded_customers) THEN 'TRUE' WHEN customer_id IN (SELECT customer_id FROM C022_excluded_customers) THEN 'FALSE' ELSE 'UNKNOWN' END AS condition_result FROM C022_customers ORDER BY customer_id
),
C022_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C022_result q),
C023_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C023_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C023_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C023_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C023_result (c1) AS (
SELECT customer_id
FROM C023_customers WHERE customer_id NOT IN (SELECT customer_id
FROM C023_excluded_customers WHERE customer_id IS NOT NULL) ORDER BY customer_id
),
C023_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C023_result q),
C024_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C024_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C024_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C024_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C024_result (c1) AS (
SELECT c.customer_id FROM C024_customers c
WHERE NOT EXISTS (SELECT 1 FROM C024_excluded_customers x
WHERE x.customer_id=c.customer_id) ORDER BY c.customer_id
),
C024_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C024_result q),
C025_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C025_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C025_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C025_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C025_result (c1, c2, c3, c4) AS (
SELECT receipt_id,day_no,amount,
SUM(amount) OVER (ORDER BY day_no,receipt_id
ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_total
FROM C025_receipts ORDER BY day_no,receipt_id
),
C025_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C025_result q),
C026_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C026_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C026_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C026_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C026_result (c1, c2, c3, c4) AS (
SELECT receipt_id,day_no,amount,
SUM(amount) OVER (ORDER BY day_no
RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_total
FROM C026_receipts ORDER BY day_no,receipt_id
),
C026_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C026_result q),
C027_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C027_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C027_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C027_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C027_result (c1, c2, c3, c4) AS (
SELECT receipt_id,day_no,amount,
SUM(amount) OVER (ORDER BY day_no,receipt_id
RANGE BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_total
FROM C027_receipts ORDER BY day_no,receipt_id
),
C027_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C027_result q),
C028_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C028_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C028_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C028_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C028_result (c1, c2, c3, c4) AS (
SELECT receipt_id,day_no,amount,
SUM(amount) OVER (ORDER BY day_no) AS running_total
FROM C028_receipts ORDER BY day_no,receipt_id
),
C028_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C028_result q),
C029_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
C029_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
C029_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
C029_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
C029_result (c1, c2, c3, c4) AS (
SELECT receipt_id,day_no,amount,
SUM(amount) OVER (ORDER BY day_no,receipt_id
ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS running_total
FROM C029_receipts ORDER BY day_no,receipt_id
),
C029_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C029_result q)
SELECT 'C020' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C020_numbered
UNION ALL
SELECT 'C021' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C021_numbered
UNION ALL
SELECT 'C022' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C022_numbered
UNION ALL
SELECT 'C023' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C023_numbered
UNION ALL
SELECT 'C024' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C024_numbered
UNION ALL
SELECT 'C025' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C025_numbered
UNION ALL
SELECT 'C026' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C026_numbered
UNION ALL
SELECT 'C027' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C027_numbered
UNION ALL
SELECT 'C028' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C028_numbered
UNION ALL
SELECT 'C029' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C029_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
