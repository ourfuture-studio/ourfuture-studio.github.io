WITH C040_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C040_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C040_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C040_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C040_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C040_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C040_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C040_result (c1) AS (
SELECT customer_id FROM C040_campaign_a UNION ALL SELECT customer_id FROM C040_campaign_b ORDER BY customer_id
),
C040_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C040_result q),
C041_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C041_campaign_b (customer_id) AS (
SELECT CAST(NULL AS NUMBER) FROM dual WHERE 1=0
),
C041_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C041_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C041_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C041_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C041_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C041_result (c1) AS (
SELECT customer_id FROM C041_campaign_a UNION SELECT customer_id FROM C041_campaign_b ORDER BY customer_id
),
C041_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C041_result q),
C042_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C042_campaign_b (customer_id) AS (
SELECT CAST(NULL AS NUMBER) FROM dual WHERE 1=0
),
C042_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C042_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C042_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C042_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C042_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C042_result (c1) AS (
SELECT customer_id FROM C042_campaign_a UNION ALL SELECT customer_id FROM C042_campaign_b ORDER BY customer_id
),
C042_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C042_result q),
C043_campaign_a (customer_id) AS (
SELECT CAST(NULL AS NUMBER) FROM dual WHERE 1=0
),
C043_campaign_b (customer_id) AS (
SELECT CAST(NULL AS NUMBER) FROM dual WHERE 1=0
),
C043_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C043_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C043_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C043_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C043_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C043_result (c1) AS (
SELECT customer_id FROM C043_campaign_a UNION SELECT customer_id FROM C043_campaign_b ORDER BY customer_id
),
C043_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C043_result q),
C044_campaign_a (customer_id) AS (
SELECT CAST(NULL AS NUMBER) FROM dual WHERE 1=0
),
C044_campaign_b (customer_id) AS (
SELECT CAST(NULL AS NUMBER) FROM dual WHERE 1=0
),
C044_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C044_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C044_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C044_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C044_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C044_result (c1) AS (
SELECT customer_id FROM C044_campaign_a UNION ALL SELECT customer_id FROM C044_campaign_b ORDER BY customer_id
),
C044_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C044_result q),
C045_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C045_campaign_b (customer_id) AS (
SELECT 33 FROM dual
UNION ALL
SELECT 44 FROM dual
),
C045_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C045_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C045_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C045_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C045_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C045_result (c1) AS (
SELECT customer_id FROM C045_campaign_a UNION SELECT customer_id FROM C045_campaign_b ORDER BY customer_id
),
C045_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C045_result q),
C046_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C046_campaign_b (customer_id) AS (
SELECT 33 FROM dual
UNION ALL
SELECT 44 FROM dual
),
C046_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C046_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C046_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C046_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C046_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C046_result (c1) AS (
SELECT customer_id FROM C046_campaign_a UNION ALL SELECT customer_id FROM C046_campaign_b ORDER BY customer_id
),
C046_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C046_result q),
C047_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C047_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C047_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C047_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C047_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C047_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C047_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C047_result (c1) AS (
SELECT customer_id FROM C047_orders GROUP BY customer_id HAVING SUM(amount) >= 15 ORDER BY customer_id
),
C047_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C047_result q),
C048_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C048_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C048_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C048_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C048_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C048_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C048_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C048_result (c1) AS (
SELECT customer_id FROM C048_orders WHERE amount >= 15 GROUP BY customer_id ORDER BY customer_id
),
C048_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C048_result q),
C049_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C049_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C049_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C049_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C049_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C049_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C049_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C049_result (c1) AS (
SELECT customer_id FROM C049_orders GROUP BY customer_id HAVING SUM(amount) >= 12 ORDER BY customer_id
),
C049_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C049_result q)
SELECT 'C040' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C040_numbered
UNION ALL
SELECT 'C041' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C041_numbered
UNION ALL
SELECT 'C042' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C042_numbered
UNION ALL
SELECT 'C043' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C043_numbered
UNION ALL
SELECT 'C044' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C044_numbered
UNION ALL
SELECT 'C045' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C045_numbered
UNION ALL
SELECT 'C046' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C046_numbered
UNION ALL
SELECT 'C047' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C047_numbered
UNION ALL
SELECT 'C048' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C048_numbered
UNION ALL
SELECT 'C049' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C049_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
