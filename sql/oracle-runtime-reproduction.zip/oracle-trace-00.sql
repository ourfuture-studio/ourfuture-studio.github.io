WITH T000_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
T000_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
T000_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
T000_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
T000_result (c1, c2, c3) AS (SELECT order_id, coupon_amount, CASE WHEN coupon_amount IS NULL THEN 0 ELSE 1 END AS counted FROM T000_orders ORDER BY order_id),
T000_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T000_result q),
T001_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
T001_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
T001_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
T001_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
T001_result (c1, c2, c3, c4) AS (SELECT order_id, amount, fee, amount+fee AS sum_input FROM T001_orders ORDER BY order_id),
T001_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T001_result q),
T002_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
T002_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
T002_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
T002_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
T002_result (c1, c2) AS (SELECT SUM(amount) AS amount_total, SUM(fee) AS fee_total FROM T002_orders),
T002_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T002_result q),
T003_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
T003_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
T003_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
T003_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
T003_result (c1, c2, c3) AS (SELECT c.customer_id, COUNT(*) AS result_rows, COUNT(o.order_id) AS order_count FROM T003_customers c LEFT JOIN T003_orders o ON c.customer_id=o.customer_id GROUP BY c.customer_id ORDER BY c.customer_id),
T003_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T003_result q),
T004_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
T004_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
T004_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
T004_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
T004_result (c1, c2, c3) AS (SELECT c.customer_id,o.order_id,o.amount FROM T004_customers c LEFT JOIN T004_orders o ON c.customer_id=o.customer_id AND o.amount>=10 ORDER BY c.customer_id,o.order_id),
T004_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T004_result q),
T005_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
T005_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
T005_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
T005_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
T005_result (c1, c2, c3, c4) AS (SELECT c.customer_id,o.order_id,o.amount,CASE WHEN o.amount>=10 THEN 'TRUE' WHEN NOT(o.amount>=10) THEN 'FALSE' ELSE 'UNKNOWN' END AS predicate FROM T005_customers c LEFT JOIN T005_orders o ON c.customer_id=o.customer_id ORDER BY c.customer_id,o.order_id),
T005_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T005_result q),
T006_customers (customer_id, customer_name) AS (
SELECT 11, '가온' FROM dual
UNION ALL
SELECT 22, '나래' FROM dual
UNION ALL
SELECT 33, '다온' FROM dual
),
T006_excluded_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT CAST(NULL AS NUMBER) FROM dual
),
T006_orders (order_id, customer_id, amount, coupon_amount, fee) AS (
SELECT 201, 11, 8, 500, 2 FROM dual
UNION ALL
SELECT 202, 11, 12, CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 203, 22, 7, 500, 3 FROM dual
),
T006_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 1, 4 FROM dual
UNION ALL
SELECT 402, 2, 6 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
UNION ALL
SELECT 404, 3, 5 FROM dual
),
T006_result (c1, c2) AS (SELECT customer_id,CASE WHEN customer_id NOT IN (SELECT customer_id FROM T006_excluded_customers) THEN 'TRUE' WHEN NOT(customer_id NOT IN (SELECT customer_id FROM T006_excluded_customers)) THEN 'FALSE' ELSE 'UNKNOWN' END AS predicate FROM T006_customers ORDER BY customer_id),
T006_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T006_result q),
T007_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
T007_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
T007_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
T007_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
T007_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
T007_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
T007_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
T007_result (c1, c2, c3) AS (SELECT order_id,coupon,CASE WHEN coupon=NULL THEN 'TRUE' WHEN NOT(coupon=NULL) THEN 'FALSE' ELSE 'UNKNOWN' END AS predicate FROM T007_null_orders ORDER BY order_id),
T007_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T007_result q),
T008_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
T008_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
T008_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
T008_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
T008_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
T008_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
T008_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
T008_result (c1, c2, c3) AS (SELECT order_id,coupon,CASE WHEN coupon IS NULL THEN 'TRUE' ELSE 'FALSE' END AS predicate FROM T008_null_orders ORDER BY order_id),
T008_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T008_result q),
T009_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
T009_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
T009_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
T009_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
T009_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
T009_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
T009_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
T009_result (c1, c2, c3) AS (SELECT customer_id,COUNT(*) AS order_count,SUM(amount) AS group_total FROM T009_orders GROUP BY customer_id ORDER BY customer_id),
T009_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T009_result q)
SELECT 'T000' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T000_numbered
UNION ALL
SELECT 'T001' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T001_numbered
UNION ALL
SELECT 'T002' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T002_numbered
UNION ALL
SELECT 'T003' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T003_numbered
UNION ALL
SELECT 'T004' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T004_numbered
UNION ALL
SELECT 'T005' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T005_numbered
UNION ALL
SELECT 'T006' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T006_numbered
UNION ALL
SELECT 'T007' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T007_numbered
UNION ALL
SELECT 'T008' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T008_numbered
UNION ALL
SELECT 'T009' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T009_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
