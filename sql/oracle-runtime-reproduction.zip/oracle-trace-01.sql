WITH T010_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
T010_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
T010_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
T010_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
T010_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
T010_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
T010_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
T010_result (c1, c2, c3) AS (SELECT c.customer_id,(SELECT COUNT(*) FROM T010_orders o WHERE o.customer_id=c.customer_id) AS matching_orders,CASE WHEN EXISTS(SELECT NULL FROM T010_orders o WHERE o.customer_id=c.customer_id) THEN 'TRUE' ELSE 'FALSE' END AS predicate FROM T010_customers c ORDER BY c.customer_id),
T010_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM T010_result q)
SELECT 'T010' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM T010_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
