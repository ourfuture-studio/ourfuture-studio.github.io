WITH C050_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C050_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C050_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C050_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C050_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C050_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C050_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C050_result (c1) AS (
SELECT customer_id FROM C050_orders WHERE amount >= 10 GROUP BY customer_id HAVING SUM(amount) >= 15 ORDER BY customer_id
),
C050_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C050_result q),
C051_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C051_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C051_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C051_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C051_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C051_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C051_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C051_result (c1) AS (
SELECT c.customer_id FROM C051_customers c WHERE EXISTS (SELECT NULL FROM C051_orders o WHERE o.customer_id = c.customer_id) ORDER BY c.customer_id
),
C051_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C051_result q),
C052_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C052_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C052_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C052_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C052_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C052_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C052_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C052_result (c1) AS (
SELECT c.customer_id FROM C052_customers c WHERE EXISTS (SELECT 1 FROM C052_orders o WHERE o.customer_id = c.customer_id) ORDER BY c.customer_id
),
C052_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C052_result q),
C053_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C053_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C053_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C053_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C053_orders (order_id, customer_id, amount) AS (
SELECT CAST(NULL AS NUMBER), CAST(NULL AS NUMBER), CAST(NULL AS NUMBER) FROM dual WHERE 1=0
),
C053_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C053_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C053_result (c1) AS (
SELECT c.customer_id FROM C053_customers c WHERE EXISTS (SELECT NULL FROM C053_orders o WHERE o.customer_id = c.customer_id) ORDER BY c.customer_id
),
C053_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C053_result q),
C054_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C054_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C054_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C054_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C054_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C054_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C054_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C054_result (c1) AS (
SELECT c.customer_id FROM C054_customers c WHERE EXISTS (SELECT NULL FROM C054_orders o) ORDER BY c.customer_id
),
C054_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C054_result q),
C055_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C055_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C055_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C055_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C055_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C055_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C055_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C055_result (c1, c2, c3) AS (
SELECT customer_id, RANK() OVER (ORDER BY score DESC) AS r, DENSE_RANK() OVER (ORDER BY score DESC) AS d FROM C055_scores ORDER BY customer_id
),
C055_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C055_result q),
C056_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C056_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C056_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C056_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C056_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C056_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C056_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C056_result (c1, c2, c3) AS (
SELECT customer_id, RANK() OVER (ORDER BY score DESC, customer_id) AS r, DENSE_RANK() OVER (ORDER BY score DESC, customer_id) AS d FROM C056_scores ORDER BY customer_id
),
C056_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C056_result q),
C057_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C057_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C057_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C057_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C057_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C057_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C057_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 90 FROM dual
UNION ALL
SELECT 44, 90 FROM dual
),
C057_result (c1, c2, c3) AS (
SELECT customer_id, RANK() OVER (ORDER BY score DESC) AS r, DENSE_RANK() OVER (ORDER BY score DESC) AS d FROM C057_scores ORDER BY customer_id
),
C057_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C057_result q),
C058_campaign_a (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
),
C058_campaign_b (customer_id) AS (
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C058_customers (customer_id) AS (
SELECT 11 FROM dual
UNION ALL
SELECT 22 FROM dual
UNION ALL
SELECT 33 FROM dual
),
C058_null_orders (order_id, coupon) AS (
SELECT 301, 500 FROM dual
UNION ALL
SELECT 302, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 303, 0 FROM dual
),
C058_orders (order_id, customer_id, amount) AS (
SELECT 501, 11, 8 FROM dual
UNION ALL
SELECT 502, 11, 7 FROM dual
UNION ALL
SELECT 503, 22, 12 FROM dual
),
C058_purchases (order_id, customer_id, menu) AS (
SELECT 401, 11, '커피' FROM dual
UNION ALL
SELECT 402, 11, '커피' FROM dual
UNION ALL
SELECT 403, 11, '차' FROM dual
UNION ALL
SELECT 404, 22, '커피' FROM dual
),
C058_scores (customer_id, score) AS (
SELECT 11, 90 FROM dual
UNION ALL
SELECT 22, 90 FROM dual
UNION ALL
SELECT 33, 80 FROM dual
UNION ALL
SELECT 44, 70 FROM dual
),
C058_result (c1, c2, c3) AS (
SELECT customer_id, RANK() OVER (ORDER BY score ASC) AS r, DENSE_RANK() OVER (ORDER BY score ASC) AS d FROM C058_scores ORDER BY customer_id
),
C058_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C058_result q),
C059_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C059_result (c1, c2) AS (
SELECT order_id, amount FROM C059_orders WHERE amount > 100 ORDER BY order_id
),
C059_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C059_result q)
SELECT 'C050' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C050_numbered
UNION ALL
SELECT 'C051' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C051_numbered
UNION ALL
SELECT 'C052' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C052_numbered
UNION ALL
SELECT 'C053' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C053_numbered
UNION ALL
SELECT 'C054' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C054_numbered
UNION ALL
SELECT 'C055' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C055_numbered
UNION ALL
SELECT 'C056' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C056_numbered
UNION ALL
SELECT 'C057' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C057_numbered
UNION ALL
SELECT 'C058' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C058_numbered
UNION ALL
SELECT 'C059' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C059_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
