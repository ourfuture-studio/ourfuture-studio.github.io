WITH C080_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C080_result (c1, c2, c3, c4) AS (
SELECT order_id, customer_id, amount, SUM(amount) OVER (PARTITION BY customer_id) AS customer_total FROM C080_orders ORDER BY order_id
),
C080_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C080_result q),
C081_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 1, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C081_result (c1, c2) AS (
SELECT customer_id, SUM(amount) AS customer_total FROM C081_orders GROUP BY customer_id ORDER BY customer_id
),
C081_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C081_result q),
C082_orders (order_id, customer_id, amount) AS (
SELECT 101, 1, 10 FROM dual
UNION ALL
SELECT 102, 2, 20 FROM dual
UNION ALL
SELECT 103, 2, 5 FROM dual
),
C082_result (c1, c2, c3, c4) AS (
SELECT order_id, customer_id, amount, SUM(amount) OVER (PARTITION BY customer_id) AS customer_total FROM C082_orders ORDER BY order_id
),
C082_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C082_result q),
C083_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 2, 6 FROM dual
UNION ALL
SELECT 402, 1, 4 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
),
C083_result (c1, c2, c3, c4, c5) AS (
SELECT receipt_id, day_no, amount, LAG(amount) OVER (ORDER BY day_no, receipt_id) AS previous_amount, LEAD(amount) OVER (ORDER BY day_no, receipt_id) AS next_amount FROM C083_receipts ORDER BY day_no, receipt_id
),
C083_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C083_result q),
C084_receipts (receipt_id, day_no, amount) AS (
SELECT 401, 3, 6 FROM dual
UNION ALL
SELECT 402, 1, 4 FROM dual
UNION ALL
SELECT 403, 2, 9 FROM dual
),
C084_result (c1, c2, c3, c4, c5) AS (
SELECT receipt_id, day_no, amount, LAG(amount) OVER (ORDER BY day_no, receipt_id) AS previous_amount, LEAD(amount) OVER (ORDER BY day_no, receipt_id) AS next_amount FROM C084_receipts ORDER BY day_no, receipt_id
),
C084_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C084_result q),
C085_nodes (node_id, parent_id) AS (
SELECT 1, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 2, 1 FROM dual
UNION ALL
SELECT 3, 1 FROM dual
UNION ALL
SELECT 4, 2 FROM dual
),
C085_result (c1, c2) AS (
SELECT p.node_id AS parent_node, c.node_id AS child_node FROM C085_nodes p JOIN C085_nodes c ON c.parent_id=p.node_id ORDER BY p.node_id, c.node_id
),
C085_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C085_result q),
C086_nodes (node_id, parent_id) AS (
SELECT 1, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 2, 1 FROM dual
UNION ALL
SELECT 3, 1 FROM dual
UNION ALL
SELECT 4, 2 FROM dual
),
C086_result (c1, c2) AS (
SELECT c.node_id AS child_node, p.node_id AS parent_node FROM C086_nodes c JOIN C086_nodes p ON c.parent_id=p.node_id ORDER BY c.node_id
),
C086_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C086_result q),
C087_nodes (node_id, parent_id) AS (
SELECT 1, CAST(NULL AS NUMBER) FROM dual
UNION ALL
SELECT 2, 1 FROM dual
UNION ALL
SELECT 3, 1 FROM dual
UNION ALL
SELECT 4, 3 FROM dual
),
C087_result (c1, c2) AS (
SELECT p.node_id AS parent_node, c.node_id AS child_node FROM C087_nodes p JOIN C087_nodes c ON c.parent_id=p.node_id ORDER BY p.node_id, c.node_id
),
C087_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C087_result q),
C088_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C088_result (c1, c2) AS (
SELECT customer_id, customer_name FROM C088_customers ORDER BY customer_id
),
C088_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C088_result q),
C089_customers (customer_id, customer_name) AS (
SELECT 1, 'MIN' FROM dual
UNION ALL
SELECT 2, 'JUN' FROM dual
UNION ALL
SELECT 3, 'SOL' FROM dual
),
C089_result (c1) AS (
SELECT COUNT(*) AS instance_count FROM C089_customers
),
C089_numbered AS (SELECT ROWNUM AS ordinal, q.* FROM C089_result q)
SELECT 'C080' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C080_numbered
UNION ALL
SELECT 'C081' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C081_numbered
UNION ALL
SELECT 'C082' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C082_numbered
UNION ALL
SELECT 'C083' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4, c5 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C083_numbered
UNION ALL
SELECT 'C084' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2, c3, c4, c5 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C084_numbered
UNION ALL
SELECT 'C085' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C085_numbered
UNION ALL
SELECT 'C086' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C086_numbered
UNION ALL
SELECT 'C087' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C087_numbered
UNION ALL
SELECT 'C088' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1, c2 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C088_numbered
UNION ALL
SELECT 'C089' AS case_id, NVL(JSON_ARRAYAGG(JSON_ARRAY(c1 NULL ON NULL RETURNING VARCHAR2(4000)) FORMAT JSON ORDER BY ordinal RETURNING VARCHAR2(4000)), '[]') AS rows_json FROM C089_numbered
UNION ALL
SELECT 'ENV' AS case_id, JSON_ARRAY(version_full NULL ON NULL RETURNING VARCHAR2(4000)) AS rows_json FROM product_component_version WHERE product LIKE 'Oracle Database%'
ORDER BY case_id;
